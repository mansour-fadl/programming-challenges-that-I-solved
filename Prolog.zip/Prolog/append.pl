append([],N,N).
append([H|M],N,[H|L]):-
    append(M,N,L).
