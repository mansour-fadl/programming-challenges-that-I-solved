before([_,L] ,L).
before([_,L|Y], M):-
    before(L,M).
