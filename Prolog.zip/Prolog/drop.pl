drop([],[],_,_).
drop([H|T],[H|L],N,I):-
    I < N, J is (I + 1),drop(T,L,N,J).
drop([_|T],L,N,I):-
    I == N,drop(T,L,N,1).
drp(T,L,N):-
    drop(T,L,N,1).


