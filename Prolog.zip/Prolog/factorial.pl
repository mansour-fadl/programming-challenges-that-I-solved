fact(0,1).
fact(N,M):-
    I is (N - 1), fact(I, L), M is( L * N).
