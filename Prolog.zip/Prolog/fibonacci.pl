fibo(0,0).
fibo(1,1).
fibo(N,M):-
       J is (N - 1), fibo(J, L),  I is (N - 2), fibo(I, K), M is (L + K).
