flat([],[]).
flat([H|T],L):-
    is_list(H), append([H],L,M),flat(T,M).
flat([H|T],[H|L]):-
    flat(T,L).


