% 1.07 (**): Flatten a nested list structure.

% my_flatten(L1,L2) :- the list L2 is obtained from the list L1 by
%    flattening; i.e. if an element of L1 is a list then it is replaced
%    by its elements, recursively.
%    (list,list) (+,?)

% Note: flatten(+List1, -List2) is a predefined predicate

my_flatten(L,[L]) :- \+ is_list(L).
my_flatten([],[]).
my_flatten([H|X],Z) :-
    my_flatten(H,Y), my_flatten(X,L), append(Y,L,Z).

