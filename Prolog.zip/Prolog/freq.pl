freq([],_,0).
freq([H|T],A,N):-
    H == A , freq(T,A,I), N is I + 1.
freq([H|T],A,N):-
    freq(T,A,N).
