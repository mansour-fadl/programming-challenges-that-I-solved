gc(N,_,N,[]).
gc(_,N,N,[]).
gc(N,M,I,[I|L]):-
    0 is N mod I, 0 is M mod I, J is I + 1, gc(N,M,J,L).
gc(N,M,I,L):-
    J is (I + 1),gc(N,M,J,L).



gcd(N,M,L):-
    gc(N,M,2,I),grt(I,L).


grt([X],X).
grt([_|I],L):-
    grt(I,L).
