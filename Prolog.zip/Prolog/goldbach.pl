isprim(1,_,_).
isprim(N,M,L):-
    M mod N =\= 0 , N1 is (N - 1), isprim(N1,M,L).

isprime(M):-
    N is (M - 1),isprim(N,M,_).




gold([],[]).

