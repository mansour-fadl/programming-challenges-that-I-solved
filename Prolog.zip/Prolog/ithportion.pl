size([],_,_,0).
size([_|T],N,J,M):-
    size(T,N,J,N1),M is N1 + 1.
ith(_,_,0,_,[]).
ith([_|T],I,L,C,M):-
    C =\= I, N is (C + 1), ith(T,I,L,N,M).

ith([H|T],I,L,C,[H|M]):-
    C == I, K is (L - 1), ith(T,I,K,C,M).

iths(L,N,J):-
    size(L,N,J,M), I is (M /N),ith(L,I,I,0,J).


