kth([],[],[],_,_).
kth([H|T],L,[H|K],N,I):-
    I < N, J is (I + 1), kth(T,L,K,N,J).
kth([H|T],[H|L],K,N,I):-
    I == N, J is (I + 1), kth(T,L,K,N,J).
kth([H|T],L,[H|K],N,I):-
    I > N, J is (I + 1), kth(T,L,K,N,J).
kt(L,M,N,I):-
    kth(L,M,N,I,1).
