las([L],L).
las([_|L],M):-
    las(L,M).
