mylist(X,[X]).
mylist(X,[_|L]):- mylist(X,L).

