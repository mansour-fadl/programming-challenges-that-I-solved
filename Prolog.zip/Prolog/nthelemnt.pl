appen([],L,L,I,N).
appen(L,[],L,I,N).
appen([H|List1],List2,[H|List3],I,N):-
    J is I + 1, 0 is (J mod N), appen(List2,List1,List3,J,N).
appen([H|List1],List2,[H|List3],I,N):-
   J is I + 1, 1 is (J mod N),appen(List2,List1,List3,J,N).
appen([H|List1],List2,[H|List3],I,N):-
    J is I + 1, appen(List1,List2,List3,J,N).

nthlmnt(L1,L2,R,Nth):- appen(L1,L2,R,1,Nth).
