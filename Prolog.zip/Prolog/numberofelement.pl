siz([],0).
siz([_|L],M):-
    siz(L,N),M is N + 1.
