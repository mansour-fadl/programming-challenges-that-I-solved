pal([],[]).
pal([H|T], [J|K]):-
    H == J ,pal(T,K).

pl(L):-
    reverse(L,M), pal(L,M).

