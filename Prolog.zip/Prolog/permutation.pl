permute([],[]).
permute([A|L],[H|L1]):-
    length([A|L],N),N =\= 0, I is random(N) + 1, kth([A|L],I,1,[H|_],P), permute(P,L1).




kth([],_,_,[],[]).
kth([A|L],I,N,[A|M],P):-
    I == N, J is (N + 1), kth(L,I,J,M,P).
kth([A|L],I,N,M,[A|P]):-
    J is (N + 1),kth(L,I,J,M,P).
