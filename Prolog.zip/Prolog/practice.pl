last([],[]).
last([_,B|L],M):-
    last([B|L],M).
last([A|L],[A|M]):-
    last(L,M).

