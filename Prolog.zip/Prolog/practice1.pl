kth([],[],_,_).
kth([_|L],M,I,N):-
    I =\= N, J is (N + 1),kth(L,M,I,J).
kth([A|L],[A|M],I,N):-
    I == N,J is (N + 1), kth(L,M,I,J).




kt(L,M,N):-
    kth(L,M,N,1).
