prime([],[]).

