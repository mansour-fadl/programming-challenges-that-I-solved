range(L,L,[]).
range(L,M,[L|N]):-
    J is (L + 1),range(J,M,N).



rangee(L,M,N):-
    J is (M + 1),range(L,J,N).
