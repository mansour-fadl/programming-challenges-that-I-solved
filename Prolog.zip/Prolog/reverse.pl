rev([],L,L).
rev([A|L],M,I):-
    app([A],M,O),rev(L,O,I).

app([],L,L).
app(L,[],L).
app([A|L],L1,[A|M]):-
    app(L,L1,M).


ref(L,M):-
    rev(L,_,M).


