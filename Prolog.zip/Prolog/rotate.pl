rot(O,O,L,L).
rot([H|T],L,N,I):-
    I < N, J is (I + 1), append(T,[H],M),rot(M,L,N,J).



rott(L,M,N):-
    rot(L,M,N,0).
