slice(_,[],_,L,J):- J is (L + 1).
slice([_|T],L,N,I,J):-
    J < N, K is (J + 1),slice(T,L,N,I,K).
slice([H|T],[H|L],N,I,J):-
    J >= N, J =< I, K is (J + 1), slice(T,L,N,I,K).


slc(L,M,N,I):-
    slice(L,M,N,I,1).

