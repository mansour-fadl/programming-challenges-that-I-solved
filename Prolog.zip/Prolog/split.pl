splt([],[],_,L,L).
splt([H|T],[H|L],M,N,I):-
    I < N, J is (I + 1), splt(T,L,M,N,J).
splt([_|T],L,T,N,I):-
    I == N, splt([],L,T,N,I).

split(I,L,M,N):-
    splt(I,L,M,N,0).

