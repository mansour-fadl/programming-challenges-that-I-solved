ist(nil).
ist(t(_,L,R)):-
    ist(L),ist(R).

ist(1,t(a,t(b,t(d,nil,nil,nil),t(e,nil,nil)),t(c,nil,t(f,t(g,nil,nil),nil)))).
ist(2,t(a,nil,nil)).
ist(3,nil).

